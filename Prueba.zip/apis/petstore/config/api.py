URL="https://petstore.swagger.io/"
API_VERSION="v2"