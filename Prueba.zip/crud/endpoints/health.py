from flask_restful import Resource

class Health(Resource):
    def get(self):
        return {"status": "ok"}, 200